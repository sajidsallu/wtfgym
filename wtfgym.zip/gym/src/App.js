import {Route,Routes} from 'react-router-dom'
import './App.css';

import { GymHomePage } from './pages/gymPage/GymHomePage';
import { PlanPage } from './pages/planPage/PlanPage';

function App() {
  return (
    <div className="App">
     
      <Routes>
       <Route path="/" element={<GymHomePage/>}></Route> 
       <Route path="/planPage" element={<PlanPage/>}></Route> 

    
    </Routes>

    </div>
  );
}

export default App;
